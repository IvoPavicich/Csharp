﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace ManejoDeArchivos
{
    class Program
    {
        static void Main(string[] args)
        {

            string ruta = @"D:\ClaseArchivo\csharp.txt";
            string directorio = @"D:\ClaseArchivo";

             

            /*
            string ruta = @"D:\ClaseArchivo\contenido.txt";

            FileInfo f = new FileInfo(ruta);

            DirectoryInfo d=    f.Directory;
            Console.WriteLine(d.Root);
            
             * /
             * /*
           string[] lineas=  File.ReadAllLines(ruta);

            foreach(string linea in lineas)
            {
                Console.WriteLine(linea);
            }
            */
            /*
            string rutaOrigen = @"D:\ClaseArchivo\examen.txt";
            string rutaDestino= @"D:\ClaseArchivo\contenido.txt";

            string contenidoArchivo= File.ReadAllText(rutaOrigen);

            File.WriteAllText(rutaDestino, contenidoArchivo);
            
             * 
             * /*
            string ruta = @"D:\ClaseArchivo\Imagenes\perrito.png";
            string rutaDestino = @"D:\Imagen\perrito.png";



           byte[] archivo=   File.ReadAllBytes(ruta);

            File.WriteAllBytes(rutaDestino, archivo);
            */
            /*
            string rutaOrigen = @"D:\ClaseArchivo\move.txt";
            string rutaDestino = @"D:\Mover\move.txt";

            File.Move(rutaOrigen, rutaDestino);
            */
            /*
            using (StreamWriter sw = File.CreateText(ruta))
            {
                sw.Write("Como estas");
                sw.Write("Compañero");
            }
            */
            /*
            string rutaOrigen = @"D:\ClaseArchivo\examen.txt";
            string rutaDestino = @"D:\Mover\examen.txt";

            File.Copy(rutaOrigen, rutaDestino);
            */
            /*
            string ruta = @"D:\ClaseArchivo\csharp.txt";



            string nombres = " Pedro Luis Jose Santiago Nelly";


            File.AppendAllText(ruta, nombres);
            */
            /*
            List<string> nombres = new List<string>();
            nombres.Add("Pedro");
            nombres.Add("Luis");
            nombres.Add("Jose");
            nombres.Add("Santiago");
            nombres.Add("Nelly");
            File.AppendAllLines(ruta, nombres);

            */
            /*
            File.Create(ruta);
            */
            /*
            DirectoryInfo dir = new DirectoryInfo(@"D:\ClaseArchivo\Cursos\EntityFramework");

            dir.Delete(true);

             * /
             * /*
            if (dir.Exists)
            {
                Console.WriteLine("Existe el directorio");
            }else
            {
                Console.WriteLine("No existe");
            }
            */
            /*
            string rutaInicio = @"D:\ClaseArchivo\Alumnos";

            string rutaFinal = @"D:\RutaMover2";


            Directory.Move(rutaInicio, rutaFinal);
            */
            /*
             string directorioActual= Directory.GetCurrentDirectory();

            string unidad = Directory.GetDirectoryRoot(directorioActual);
            Console.WriteLine("Directorio " + directorioActual);

            Console.WriteLine("Unidad " + unidad);
            */
            /*
            List<string> lista = Directory.EnumerateFileSystemEntries(ruta,"*x").ToList();

            foreach(string item in lista)
            {
                Console.WriteLine(item);
            }
            */
            Console.ReadLine();
            
            /*
            List<string> lista = Directory.EnumerateFiles(ruta, "t*").ToList();

            foreach(string item in lista)
            {
                Console.WriteLine(item);
            }
            */
            //Directory.CreateDirectory(ruta);
            // Directory.Delete(ruta,true);

            /*
            List<string> lista=   Directory.EnumerateDirectories(ruta,"*a").ToList();
             foreach(string elemento in lista)
            {
                Console.WriteLine(elemento);
            }
            */
            Console.ReadLine();
        }
    }
}
